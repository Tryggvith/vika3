#include "relationstable.h"

RelationsTable::RelationsTable()
{

}
