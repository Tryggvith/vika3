#ifndef RELATIONSTABLE_H
#define RELATIONSTABLE_H


class RelationsTable
{
public:
    RelationsTable();
};

#endif // RELATIONSTABLE_H
